ALTER TABLE `users`
  ADD COLUMN `clothes` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL
;